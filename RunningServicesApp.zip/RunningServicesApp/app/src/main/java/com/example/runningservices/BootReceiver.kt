package com.example.runningservices

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Shortcut.isEnabled(context)) Shortcut.show(context)
    }
}
