package com.example.runningservices

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var listBox: LinearLayout
    private lateinit var ramText: TextView
    private lateinit var ramBar: ProgressBar
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 10_000) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(8))
        }
        root.addView(TextView(this).apply { text = "Running services"; textSize = 22f })
        ramBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
        }
        root.addView(ramBar, LinearLayout.LayoutParams(-1, dp(12)).apply { topMargin = dp(8) })
        ramText = TextView(this).apply { textSize = 12f; alpha = .7f }
        root.addView(ramText)

        val pin = CheckBox(this).apply {
            text = "Pin shortcut in notification shade"
            isChecked = Shortcut.isEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, on ->
                if (on && Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                Shortcut.setEnabled(this@MainActivity, on)
            }
        }
        root.addView(pin)

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(listBox) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (Shortcut.isEnabled(this)) Shortcut.show(this)
    }

    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick) }

    private fun refresh() {
        Thread {
            val dump = RootShell.run("dumpsys activity services")
            if (dump.isBlank()) {
                runOnUiThread { ramText.text = "No data - is root access granted?" }
                return@Thread
            }
            val apps = ServiceParser.parse(dump)
            val (total, avail) = ServiceParser.fillMemory(apps)
            apps.sortedByDescending { it.rssKb }.let { sorted ->
                runOnUiThread { render(sorted, total, avail) }
            }
        }.start()
    }

    private fun mb(kb: Long) = if (kb >= 1_048_576) "%.1f GB".format(kb / 1_048_576.0) else "${kb / 1024} MB"

    private fun render(apps: List<AppProc>, total: Long, avail: Long) {
        if (total > 0) ramBar.progress = ((total - avail) * 100 / total).toInt()
        ramText.text = "Used ${mb(total - avail)} · Free ${mb(avail)} · " +
            "${apps.size} apps, ${apps.sumOf { it.svcs.size }} services"
        listBox.removeAllViews()
        for (a in apps) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#2A2C33")); cornerRadius = dp(12).toFloat()
                }
                setOnClickListener { showActions(a) }
            }
            card.addView(TextView(this).apply {
                text = "${a.proc}   ${if (a.rssKb > 0) mb(a.rssKb) else ""}"
                textSize = 15f
            })
            val fgCount = a.svcs.count { it.fg }
            card.addView(TextView(this).apply {
                text = "PID ${a.pid} · user ${a.user} · ${a.svcs.size} service(s)" +
                    if (fgCount > 0) " · $fgCount foreground" else ""
                textSize = 12f; alpha = .65f
            })
            card.addView(TextView(this).apply {
                text = a.svcs.joinToString("\n") { (if (it.fg) "● " else "○ ") + it.comp.substringAfter('/') }
                textSize = 12f
                setPadding(0, dp(6), 0, 0)
            })
            listBox.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
    }

    private fun showActions(a: AppProc) {
        val items = mutableListOf("Force stop app", "Kill process")
        items += a.svcs.map { "Stop service: " + it.comp.substringAfter('/') }
        AlertDialog.Builder(this)
            .setTitle(a.proc)
            .setItems(items.toTypedArray()) { _, i ->
                val cmd = when (i) {
                    0 -> "am force-stop ${a.pkg}"
                    1 -> "kill ${a.pid}"
                    else -> "am stopservice -n '${a.svcs[i - 2].comp}'"
                }
                Thread {
                    RootShell.run(cmd)
                    Thread.sleep(600)
                    refresh()
                }.start()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
