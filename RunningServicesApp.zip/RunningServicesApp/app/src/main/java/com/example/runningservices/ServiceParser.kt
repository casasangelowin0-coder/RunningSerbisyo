package com.example.runningservices

data class Svc(val comp: String, val fg: Boolean, val created: String)

data class AppProc(
    val pid: Int,
    val proc: String,
    val pkg: String,
    val user: String,
    val svcs: MutableList<Svc> = mutableListOf(),
    var rssKb: Long = 0,
)

object ServiceParser {
    private val head = Regex("""^\w+ u(\d+) ([^\s}]+)\}""")
    private val app = Regex("""app=ProcessRecord\{\w+ (\d+):([^/}]+)""")
    private val created = Regex("""createTime=(\S+)""")
    private val splitter = Regex("""(?m)^\s*\* ServiceRecord\{""")

    fun parse(dump: String): List<AppProc> {
        val cut = dump.substringBefore("Connection bindings to services:")
        val byPid = LinkedHashMap<Int, AppProc>()
        for (block in cut.split(splitter).drop(1)) {
            val h = head.find(block) ?: continue
            val a = app.find(block) ?: continue // service record without a live process
            val comp = h.groupValues[2]
            val pid = a.groupValues[1].toInt()
            val p = byPid.getOrPut(pid) {
                AppProc(pid, a.groupValues[2], comp.substringBefore('/'), h.groupValues[1])
            }
            p.svcs += Svc(
                comp,
                block.contains("isForeground=true"),
                created.find(block)?.groupValues?.get(1) ?: "",
            )
        }
        return byPid.values.toList()
    }

    /** Fills rssKb for each process and returns (totalKb, availableKb). */
    fun fillMemory(apps: List<AppProc>): Pair<Long, Long> {
        if (apps.isEmpty()) return 0L to 0L
        val pids = apps.joinToString(" ") { it.pid.toString() }
        val out = RootShell.run(
            "for p in $pids; do echo \"\$p \$(grep VmRSS /proc/\$p/status 2>/dev/null)\"; done;" +
                "grep -E 'MemTotal|MemAvailable' /proc/meminfo"
        )
        var total = 0L
        var avail = 0L
        val rss = HashMap<Int, Long>()
        for (line in out.lines()) {
            val t = line.trim().split(Regex("\\s+"))
            when {
                t.firstOrNull() == "MemTotal:" -> total = t.getOrNull(1)?.toLongOrNull() ?: 0
                t.firstOrNull() == "MemAvailable:" -> avail = t.getOrNull(1)?.toLongOrNull() ?: 0
                t.getOrNull(1) == "VmRSS:" ->
                    t[0].toIntOrNull()?.let { rss[it] = t.getOrNull(2)?.toLongOrNull() ?: 0 }
            }
        }
        apps.forEach { it.rssKb = rss[it.pid] ?: 0 }
        return total to avail
    }
}
