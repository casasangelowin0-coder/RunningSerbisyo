package com.example.runningservices

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

/** Persistent "tap to open" notification in the notification shade. */
object Shortcut {
    private const val CHANNEL = "shortcut"
    private const val ID = 1
    private const val PREFS = "prefs"
    private const val KEY = "pin_notification"

    fun isEnabled(c: Context) = c.getSharedPreferences(PREFS, 0).getBoolean(KEY, false)

    fun setEnabled(c: Context, on: Boolean) {
        c.getSharedPreferences(PREFS, 0).edit().putBoolean(KEY, on).apply()
        if (on) show(c) else hide(c)
    }

    fun show(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Shortcut", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, CHANNEL)
        else @Suppress("DEPRECATION") Notification.Builder(c)
        nm.notify(
            ID,
            b.setSmallIcon(R.drawable.ic_tile)
                .setContentTitle("Running services")
                .setContentText("Tap to open")
                .setOngoing(true)
                .setContentIntent(pi)
                .build()
        )
    }

    fun hide(c: Context) {
        c.getSystemService(NotificationManager::class.java).cancel(ID)
    }
}
