package com.example.runningservices

object RootShell {
    /** Runs a command as root and returns combined stdout+stderr ("" on failure). */
    fun run(cmd: String): String = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Exception) {
        ""
    }
}
