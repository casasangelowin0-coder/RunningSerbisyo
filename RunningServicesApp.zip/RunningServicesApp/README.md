# Running Services (root)

Open in Android Studio (Hedgehog or newer) -> let Gradle sync -> Run, or `gradle assembleDebug`.
Requires root (KernelSU Next / Magisk). Grant the su prompt on first launch.

Shortcuts:
- Quick Settings tile: pull down shade -> pencil/edit -> drag "Running services" into the panel.
- Notification: tick "Pin shortcut in notification shade" in the app.
